<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\StudentController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/Item', function () {
    return view('admin.Item');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::group(['middleware' => 'auth'], function () {

    

    //======= ADMIN =========

    Route::get('/Admin', [AdminController::class, 'index'])->name('adminIndex');

    Route::get('/Admin/Add', function () {
        return view('admin.Add');
    })->name('admin.add');

    Route::post('/Admin/Add', [AdminController::class, 'store'])->name('admin.store');

    Route::get('/Admin/Edit/{id}', [AdminController::class, 'edit'])->name('admin.edit');

    Route::get('/Admin/Item/{id}', [AdminController::class, 'item'])->name('admin.item');

    Route::post('/Admin/Update/{id}', [AdminController::class, 'update'])->name('admin.update');


    Route::post('/Admin/Delete/{id}', [AdminController::class, 'destroy'])->name('admin.destroy');


    //======= ADMIN =========




    Route::get('/Student', [StudentController::class, 'index'])->name('student.index');
    Route::get('/Student/Item/{id}', [StudentController::class, 'item'])->name('student.item');


});








