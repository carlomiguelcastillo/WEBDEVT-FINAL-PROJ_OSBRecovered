@extends('layouts.master')


@section('title', 'Student')

@section('content')
  


  <table id="dt-filter-search" class="table" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Item ID 
      </th>
      <th class="th-sm">Description
      </th>
      <th class="th-sm">Type
      </th>
      <th class="th-sm">Area Found
      </th>
      <th class="th-sm">Date Found
      </th>
       <th class="th-sm">Status
      </th>
      <th class="th-sm">Action
      </th>
    </tr>
  </thead>
  <tbody>

      @foreach($items as  $item)
        <tr>
      <td>{{$item->itemID }}</td>
      <td>{{$item->description}}</td>
      <td>{{$item->type }}</td>
      <td>{{$item->areaFound }}</td>
      
      <td>{{$item->dateFound->format('Y-m-d')}}</td>
       <td>{{$item->status }}</td>
    
    
      <td  >

           <a href="{{ route('student.item', $item->itemID) }}"
                          class="btn-sm btn-info btn-rounded">
                          View Item
                        </a>  <br/> <br/>
      </td>

      </tr>
      @endforeach
    
    </tbody>
    <tfoot>
      <tr>
        <th>Position
        </th>
        <th>Office
        </th>
        <th>Age
        </th>
        <th>Start date
      </th>
      <th>Salary
      </th>
         <th>Salary
      </th>
        </th>
         <th>Action
      
    </tr>
  </tfoot>
  </table>

@endsection