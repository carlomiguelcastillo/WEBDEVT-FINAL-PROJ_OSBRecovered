@extends('layouts.master')


@section('title', 'Item')

@section('content')
  
  <div class="row vh-100" style="border: 1px solid green;"" > 


    <div class="col align-self-center" >

      <img src="{{URL::asset('/storage/images/'. $item->image)}}" class="img-fluid"/>    
    
    </div>
 
  
    <div class="col" style="border: 1px solid green;" >
   

         
            <p class="pt-1">{{ucfirst($item->description)}}</p>
            <div class="table-responsive">
              <table class="table table-sm table-borderless mb-0">
                <tbody>
                  <tr>
                    <th class="pl-0 w-25" scope="row"><strong>Type: </strong></th>
                    <td>{{ucfirst($item->type)}}</td>
                  </tr>
                  <tr>
                    <th class="pl-0 w-25" scope="row"><strong>AreaFound: </strong></th>
                    <td>{{ucfirst($item->areaFound)}}</td>
                  </tr>
                  <tr>
                    <th class="pl-0 w-25" scope="row"><strong>Date Found: </strong></th>
                    <td>{{$item->dateFound->format('Y-m-d')}}</td>
                  </tr>
                    <tr>
                    <th class="pl-0 w-25" scope="row"><strong>Status: </strong></th>
                    <td>{{ucfirst($item->status) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <hr>
         
            <a href ="{{ route('adminIndex')}}" type="button" class="btn btn-primary btn-md mr-1 mb-2 waves-effect waves-light">Back</a>
          
    
    </div>
  
  </div>

@endsection