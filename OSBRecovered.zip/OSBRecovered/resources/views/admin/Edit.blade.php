@extends('layouts.master')


@section('title', 'Admin Dashboard')

@section('content')
  


 <form enctype="multipart/form-data" action="{{ route('admin.update', $item->itemID) }}" method="POST" class="border border-light p-5 mx-auto" style="max-width: 500px">

    @csrf

    <p class="h4 mb-4 text-center">Edit Item</p>


    <label for="desription">Description</label>
    <input type="text" name="description" class="form-control mb-4"  value="{{$item->description}}"required>


    <label for="type">Type</label>
    <input type="text" name="type" class="form-control mb-4" value="{{$item->type}}" required>

    <label for="areaFound">Area Found</label>
    <input type="text" name="areaFound" class="form-control mb-4"  value="{{$item->areaFound}}"required>

    <label for="dateFound">Date Found</label>
    <input type="date" name="dateFound" class="form-control mb-4"  value="{{$dateFound}}" required>

    <label for="status">Status</label>
    <input type="text" name="status" class="form-control mb-4"  value= "{{$item->status}}" required>


   
    <div class="input-group mb-4">
        <div class="input-group-prepend">
            <span class="input-group-text">Upload</span>
        </div>
        <div class="custom-file">
            <input type="file" name="image"class="custom-file-input" id="image" aria-describedby="image">
            <label class="custom-file-label" for="image">Upload Image</label>
        </div>
    </div>


         <div class="form-row">
                <div class="col">
                    <!-- First name -->
                     <a href ="{{ route('adminIndex')}}" class="btn btn-success btn-block" >Back</a>  
                </div>
                <div class="col">
                    <!-- Last name -->
                   <button class="btn btn-success btn-block" type="submit">Save</button>
                </div>
            </div>

  
</form>

@endsection