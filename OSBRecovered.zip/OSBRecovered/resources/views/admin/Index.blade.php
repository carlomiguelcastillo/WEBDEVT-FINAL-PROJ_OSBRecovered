@extends('layouts.master')


@section('title', 'Admin Dashboard')

@section('content')
  

  <a type="button" 
  href="{{ route('admin.add') }}" 
  class="btn btn-success btn-sm float-right ml-4">Add</a>

                               
  <table id="dt-filter-search" class="table" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Item ID 
      </th>
      <th class="th-sm">Description
      </th>
      <th class="th-sm">Type
      </th>
      <th class="th-sm">Area Found
      </th>
      <th class="th-sm">Date Found
      </th>
       <th class="th-sm">Status
      </th>
      <th class="th-sm">Action
      </th>
    </tr>
  </thead>
  <tbody>

  @foreach($items as $item)
       <tr>
      <td>{{$item->itemID }}</td>
      <td>{{$item->description}}</td>
      <td>{{$item->type }}</td>
      <td>{{$item->areaFound }}</td>
      
      <td>{{$item->dateFound->format('Y-m-d')}}</td>
       <td>{{$item->status }}</td>
    
    
      <td>

 
          <form action="{{ route('admin.destroy', $item->itemID) }}" method="POST">
                      @csrf
                     
        
                      <a href="{{ route('admin.item', $item->itemID) }}"
                          class="btn-sm btn-info btn-rounded">
                          View Item
                        </a>  

                        <a href="{{ route('admin.edit', $item->itemID) }}"
                          class="btn-sm btn-warning btn-rounded" style="margin-left: 1em"> 
                          Edit
                        </a>  

                        <button type="submit" title="delete"  onclick='return confirm("Are you sure you want to delete?");' class="btn-sm btn-danger btn-rounded" style="margin-left: 1em">
                            Delete
                        </button>

                    </form>
      </td>

      </tr>
  @endforeach
 


    </tbody>
    <tfoot>
         <tr>
      <th class="th-sm">Item ID 
      </th>
      <th class="th-sm">Description
      </th>
      <th class="th-sm">Type
      </th>
      <th class="th-sm">Area Found
      </th>
      <th class="th-sm">Date Found
      </th>
       <th class="th-sm">Status
      </th>
      <th class="th-sm">Action
      </th>
    </tr>
    </tr>
  </tfoot>
  </table>

@endsection