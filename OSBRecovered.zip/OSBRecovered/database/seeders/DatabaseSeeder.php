<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'OSB',
            'email' => 'OSB@benilde.edu.ph',
            'password' => Hash::make('OSBBENILDE'),
            'role' => 'Admin',
        ]);

        User::create([
            'name' => 'Student',
            'email' => 'Student@benilde.edu.ph',
            'password' => Hash::make('STUDENTBENILDE'),
            'role' => 'Student',
        ]);
    }
}
