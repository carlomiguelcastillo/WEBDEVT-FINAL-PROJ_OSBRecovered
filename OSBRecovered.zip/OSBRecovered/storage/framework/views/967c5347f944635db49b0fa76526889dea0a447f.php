<html>
    <head>
        <title>OSB Recovered - <?php echo $__env->yieldContent('title'); ?> </title>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.0/css/mdb.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/datatables.min.css')); ?>">
 
 <link href="<?php echo e(URL::asset('css/datatables.min.css')); ?>" rel="stylesheet" type="text/css" >

    <style>


      .form-control:focus {
        border-color: rgba(126, 239, 104, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset,
          0 0 8px rgba(126, 239, 104, 0.6);
        outline: 0 none;    }

    
      .pagination .page-item.active .page-link{
        background-color: #00C851 !important;
        }
        
       #dt-filter-search tfoot th:nth-last-child(1) input {
            visibility:hidden;
          }
        
     
    </style>
    </head>

    
    <body class="d-flex flex-column min-vh-100">
        <div class="wrapper flex-grow-1">
        <nav class="navbar navbar-expand-md navbar-dark bg-success">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                      OSB Recovered
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>
                            
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main>

        <div class="container mt-3">
            <?php echo $__env->yieldContent('content'); ?>


        </div>
        </main>

        </div>

   <footer class="page-footer font-small  bg-success text-white">
        <div class="footer-copyright text-center  py-3">Final Project by: Jj Floresca, Pau Sierra   
    </div>

<!-- JQuery -->

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
    
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.0/js/mdb.min.js"></script>
     <script>
      $(document).ready(function () {
        $("#dt-filter-search").dataTable({
         'aoColumnDefs': [{
                'bSortable': false,
                'aTargets': [-1] /* 1st one, start by the right */
            }],
          initComplete: function () {
            this.api()
              .columns()
              .every(function () {
                var column = this;
                var search = $(
                  `<input class="form-control form-control-sm" type="text" placeholder="Search">`
                )
                  .appendTo($(column.footer()).empty())
                  .on("change input", function () {
                    var val = $(this).val();

                    column.search(val ? val : "", true, false).draw();
                  });
              });
          },
        });
      });
    </script>


</body>



</html><?php /**PATH C:\xampp\htdocs\OSBRecovered - master\resources\views/layouts/master.blade.php ENDPATH**/ ?>