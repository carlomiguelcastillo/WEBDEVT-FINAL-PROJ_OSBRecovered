


<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  


 <form enctype="multipart/form-data" action="<?php echo e(route('admin.update', $item->itemID)); ?>" method="POST" class="border border-light p-5 mx-auto" style="max-width: 500px">

    <?php echo csrf_field(); ?>

    <p class="h4 mb-4 text-center">Edit Item</p>


    <label for="desription">Description</label>
    <input type="text" name="description" class="form-control mb-4"  value="<?php echo e($item->description); ?>"required>


    <label for="type">Type</label>
    <input type="text" name="type" class="form-control mb-4" value="<?php echo e($item->type); ?>" required>

    <label for="areaFound">Area Found</label>
    <input type="text" name="areaFound" class="form-control mb-4"  value="<?php echo e($item->areaFound); ?>"required>

    <label for="dateFound">Date Found</label>
    <input type="date" name="dateFound" class="form-control mb-4"  value="<?php echo e($dateFound); ?>" required>

    <label for="status">Status</label>
    <input type="text" name="status" class="form-control mb-4"  value= "<?php echo e($item->status); ?>" required>


   
    <div class="input-group mb-4">
        <div class="input-group-prepend">
            <span class="input-group-text">Upload</span>
        </div>
        <div class="custom-file">
            <input type="file" name="image"class="custom-file-input" id="image" aria-describedby="image">
            <label class="custom-file-label" for="image">Upload Image</label>
        </div>
    </div>


         <div class="form-row">
                <div class="col">
                    <!-- First name -->
                     <a href ="<?php echo e(route('adminIndex')); ?>" class="btn btn-success btn-block" >Back</a>  
                </div>
                <div class="col">
                    <!-- Last name -->
                   <button class="btn btn-success btn-block" type="submit">Save</button>
                </div>
            </div>

  
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OSBRecovered\resources\views/admin/Edit.blade.php ENDPATH**/ ?>