


<?php $__env->startSection('title', 'Item'); ?>

<?php $__env->startSection('content'); ?>
  
  <div class="row vh-100" style="border: 1px solid green;"" > 


    <div class="col align-self-center" >

      <img src="<?php echo e(URL::asset('/storage/images/'. $item->image)); ?>" class="img-fluid"/>    
    
    </div>
 
  
    <div class="col" style="border: 1px solid green;" >
   

         
            <p class="pt-1"><?php echo e(ucfirst($item->description)); ?></p>
            <div class="table-responsive">
              <table class="table table-sm table-borderless mb-0">
                <tbody>
                  <tr>
                    <th class="pl-0 w-25" scope="row"><strong>Type: </strong></th>
                    <td><?php echo e(ucfirst($item->type)); ?></td>
                  </tr>
                  <tr>
                    <th class="pl-0 w-25" scope="row"><strong>AreaFound: </strong></th>
                    <td><?php echo e(ucfirst($item->areaFound)); ?></td>
                  </tr>
                  <tr>
                    <th class="pl-0 w-25" scope="row"><strong>Date Found: </strong></th>
                    <td><?php echo e($item->dateFound->format('Y-m-d')); ?></td>
                  </tr>
                    <tr>
                    <th class="pl-0 w-25" scope="row"><strong>Status: </strong></th>
                    <td><?php echo e(ucfirst($item->status)); ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <hr>
         
            <a href ="<?php echo e(route('adminIndex')); ?>" type="button" class="btn btn-primary btn-md mr-1 mb-2 waves-effect waves-light">Back</a>
          
    
    </div>
  
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OSBRecovered\resources\views/admin/Item.blade.php ENDPATH**/ ?>