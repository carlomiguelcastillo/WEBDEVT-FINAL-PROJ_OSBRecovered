


<?php $__env->startSection('title', 'Student'); ?>

<?php $__env->startSection('content'); ?>
  


  <table id="dt-filter-search" class="table" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Item ID 
      </th>
      <th class="th-sm">Description
      </th>
      <th class="th-sm">Type
      </th>
      <th class="th-sm">Area Found
      </th>
      <th class="th-sm">Date Found
      </th>
       <th class="th-sm">Status
      </th>
      <th class="th-sm">Action
      </th>
    </tr>
  </thead>
  <tbody>

      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
      <td><?php echo e($item->itemID); ?></td>
      <td><?php echo e($item->description); ?></td>
      <td><?php echo e($item->type); ?></td>
      <td><?php echo e($item->areaFound); ?></td>
      
      <td><?php echo e($item->dateFound->format('Y-m-d')); ?></td>
       <td><?php echo e($item->status); ?></td>
    
    
      <td  >

           <a href="<?php echo e(route('student.item', $item->itemID)); ?>"
                          class="btn-sm btn-info btn-rounded">
                          View Item
                        </a>  <br/> <br/>
      </td>

      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
    <tfoot>
      <tr>
        <th>Position
        </th>
        <th>Office
        </th>
        <th>Age
        </th>
        <th>Start date
      </th>
      <th>Salary
      </th>
         <th>Salary
      </th>
        </th>
         <th>Action
      
    </tr>
  </tfoot>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OSBRecovered\resources\views/student/Index.blade.php ENDPATH**/ ?>