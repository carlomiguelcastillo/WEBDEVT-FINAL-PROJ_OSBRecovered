


<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  

  <a type="button" 
  href="<?php echo e(route('admin.add')); ?>" 
  class="btn btn-success btn-sm float-right ml-4">Add</a>

                               
  <table id="dt-filter-search" class="table" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Item ID 
      </th>
      <th class="th-sm">Description
      </th>
      <th class="th-sm">Type
      </th>
      <th class="th-sm">Area Found
      </th>
      <th class="th-sm">Date Found
      </th>
       <th class="th-sm">Status
      </th>
      <th class="th-sm">Action
      </th>
    </tr>
  </thead>
  <tbody>

  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
      <td><?php echo e($item->itemID); ?></td>
      <td><?php echo e($item->description); ?></td>
      <td><?php echo e($item->type); ?></td>
      <td><?php echo e($item->areaFound); ?></td>
      
      <td><?php echo e($item->dateFound->format('Y-m-d')); ?></td>
       <td><?php echo e($item->status); ?></td>
    
    
      <td>

 
          <form action="<?php echo e(route('admin.destroy', $item->itemID)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                     
        
                      <a href="<?php echo e(route('admin.item', $item->itemID)); ?>"
                          class="btn-sm btn-info btn-rounded">
                          View Item
                        </a>  

                        <a href="<?php echo e(route('admin.edit', $item->itemID)); ?>"
                          class="btn-sm btn-warning btn-rounded" style="margin-left: 1em"> 
                          Edit
                        </a>  

                        <button type="submit" title="delete"  onclick='return confirm("Are you sure you want to delete?");' class="btn-sm btn-danger btn-rounded" style="margin-left: 1em">
                            Delete
                        </button>

                    </form>
      </td>

      </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 


    </tbody>
    <tfoot>
         <tr>
      <th class="th-sm">Item ID 
      </th>
      <th class="th-sm">Description
      </th>
      <th class="th-sm">Type
      </th>
      <th class="th-sm">Area Found
      </th>
      <th class="th-sm">Date Found
      </th>
       <th class="th-sm">Status
      </th>
      <th class="th-sm">Action
      </th>
    </tr>
    </tr>
  </tfoot>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OSBRecovered\resources\views/admin/Index.blade.php ENDPATH**/ ?>