<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Item;

class StudentController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $items = Item::all();

        return view('student.Index' ,compact('items'));

    }
    
    public function item($id)
    {
        $item = Item::find($id);


       
        return view('student.Item' ,compact('item'));

    }


}
