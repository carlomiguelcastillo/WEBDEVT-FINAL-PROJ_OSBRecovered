<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Item;


class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $items = Item::all();


       
        return view('admin.Index' ,compact('items'));

    }

    
    public function item($id)
    {
        $item = Item::find($id);


      

      
       
        return view('admin.Item' ,compact('item'));

    }

 
    public function store(Request $request)
    {

            $item = new Item;
            $item->description = $request->description;
            $item->type = $request->type;
            $item->areaFound = $request->areaFound;
            $item->status = $request->status;           
            $item->dateFound = $request->dateFound;

      
            if($request->hasFile('image')){

                $filename = $request->image->getClientOriginalName();
                $request->image->storeAs('images',$filename,'public');

                $item->image = $filename;
            }else{
                $item->image = null;
            }

            $item->save();

        return redirect(route('adminIndex'));

    }


    public function edit($id)
    {

        if($id == null){
            return redirect(route('adminIndex'));
        }
      

        $item = Item::find($id);

        if($item == null){
            return redirect(route('adminIndex'));
        }

        
        $dateFound = date_format($item->dateFound, 'Y-m-d');

     
         return view('admin.Edit' ,compact('item','dateFound'));

    }

   
    
    public function update(Request $request, $id)
    {

        $item = Item::find($id);
        
        $item->description = $request->description;
        $item->type = $request->type;
        $item->areaFound = $request->areaFound;
        $item->status = $request->status;
     
        $item->dateFound = $request->dateFound;


        if($request->hasFile('image')){

            $filename = $request->image->getClientOriginalName();
            $request->image->storeAs('images',$filename,'public');

            $item->image = $filename;
        }

        $item->save();


        return redirect(route('adminIndex'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Item::where('itemID', '=', $id)->delete();

        return redirect()->back();

    }
}
